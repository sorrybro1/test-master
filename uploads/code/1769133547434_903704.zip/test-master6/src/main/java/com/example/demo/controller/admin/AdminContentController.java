package com.example.demo.controller.admin;

import com.example.demo.mapper.ContentMapper;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.example.demo.entity.Content;
import com.example.demo.entity.User;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@RestController
@RequestMapping("/admin-api/contents")
@RequiredArgsConstructor
public class AdminContentController {

    private final ContentMapper contentMapper;

    private boolean isAdmin(HttpSession session) {
        Object adminLogin = session.getAttribute("adminLogin");
        if (!(adminLogin instanceof Boolean) || !((Boolean) adminLogin)) return false;
        Object roleObj = session.getAttribute("role");
        int role = -1;
        try { role = Integer.parseInt(String.valueOf(roleObj)); } catch (Exception ignored) {}
        return role == 0 || role == 3;
    }

    // bootstrap-table 分页：返回 {total, rows}
    @PostMapping("/page")
    public Map<String, Object> page(@RequestParam(defaultValue = "10") int limit,
                                    @RequestParam(defaultValue = "0") int offset,
                                    @RequestParam(required = false) String title,
                                    HttpSession session) {
        if (!isAdmin(session)) {
            return Map.of("total", 0, "rows", List.of());
        }
        String t = (title == null) ? "" : title.trim();

        long total = contentMapper.countForAdmin(t);
        List<Map<String, Object>> rows = contentMapper.pageForAdmin(offset, limit, t);

        Map<String, Object> res = new HashMap<>();
        res.put("total", total);
        res.put("rows", rows);
        return res;
    }

    @PostMapping("/deleteOne")
    public Map<String, Object> deleteOne(@RequestParam("id") Integer id, HttpSession session) {
        if (!isAdmin(session)) return Map.of("success", false, "msg", "未登录或无权限");
        if (id == null) return Map.of("success", false, "msg", "id不能为空");

        int n = contentMapper.deleteById(id);
        return Map.of("success", n > 0, "msg", n > 0 ? "删除成功" : "删除失败");
    }

    // ids=1,2,3
    @PostMapping("/deleteBatch")
    public Map<String, Object> deleteBatch(@RequestParam("ids") String ids, HttpSession session) {
        if (!isAdmin(session)) return Map.of("success", false, "msg", "未登录或无权限");
        if (ids == null || ids.trim().isEmpty()) return Map.of("success", false, "msg", "ids不能为空");

        List<Integer> idList = new ArrayList<>();
        for (String s : ids.split(",")) {
            if (s == null || s.trim().isEmpty()) continue;
            try { idList.add(Integer.parseInt(s.trim())); } catch (Exception ignored) {}
        }
        if (idList.isEmpty()) return Map.of("success", false, "msg", "ids格式不正确");

        int n = contentMapper.deleteBatchIds(idList);
        return Map.of("success", true, "msg", "批量删除成功，删除数量：" + n);
    }

    @PostMapping(value = "/create", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> create(
            @RequestParam(value="tid", required=false) String tidStr,
            @RequestParam("title") String title,
            @RequestParam("pid") Integer pid,
            @RequestParam("codetext") String codetext,

            @RequestParam(value = "content", required = false, defaultValue = "") String content,
            @RequestParam(value = "experPurpose", required = false, defaultValue = "") String experPurpose,
            @RequestParam(value = "experTheory", required = false, defaultValue = "") String experTheory,
            @RequestParam(value = "ariParameter", required = false, defaultValue = "") String ariParameter,
            @RequestParam(value = "ariFlow", required = false, defaultValue = "") String ariFlow,
            @RequestParam(value = "comResults", required = false, defaultValue = "") String comResults,

            @RequestPart(value = "import_scode", required = false) MultipartFile import_scode,
            @RequestPart(value = "import_sdll", required = false) MultipartFile import_sdll,

            HttpSession session
    ) {
        try {
            Integer tid = null;
            try {
                if (tidStr != null && !tidStr.trim().isEmpty()) {
                    tid = Integer.parseInt(tidStr.trim());
                }
            } catch (Exception e) {
                return Map.of("success", false, "msg", "tid必须是数字，当前=" + tidStr);
            }
            if (tid == null) {
                return Map.of("success", false, "msg", "请选择分类（tid不能为空）");
            }

            if (!isAdmin(session)) {
                return Map.of("success", false, "msg", "未登录或无权限");
            }
            if (tid == null) return Map.of("success", false, "msg", "tid不能为空");
            if (title == null || title.trim().isEmpty()) return Map.of("success", false, "msg", "标题不能为空");
            if (pid == null) return Map.of("success", false, "msg", "排序不能为空");
            if (pid < 1 || pid > 30) return Map.of("success", false, "msg", "排序只能是1-30之间");
            if (codetext == null || codetext.trim().isEmpty()) return Map.of("success", false, "msg", "源码不能为空");

            // 取当前管理员 uid（AdminAuthController 登录时把 user 放进 session 了）
            String uid = null;
            Object userObj = session.getAttribute("user");
            if (userObj instanceof User u) {
                uid = u.getUid();
            }
            if (uid == null || uid.isBlank()) {
                return Map.of("success", false, "msg", "无法获取管理员uid，请重新登录");
            }

            Content c = new Content();
            c.setTid(tid);
            c.setPid(pid);
            c.setTitle(title.trim());

            // BLOB 字段：把 String 转成 byte[]
            c.setCodetextBytes(codetext.getBytes(StandardCharsets.UTF_8));
            c.setContentBytes(content.getBytes(StandardCharsets.UTF_8));

            c.setExperPurpose(experPurpose);
            c.setExperTheory(experTheory);
            c.setAriParameter(ariParameter);
            c.setAriFlow(ariFlow);
            c.setComResults(comResults);

            c.setUid(uid);
            c.setCreat_time(nowStr());

            // 现在你暂时不上传文件：这里先不强制，后续再完善上传即可
            // 如果你想先留空：scode/sdll 不设置也行
            // 以后要做上传：这里再把文件存到 uploads 并写入 scode/sdll

            int ins = contentMapper.insert(c);
            if (ins > 0) {
                return Map.of("success", true, "msg", "添加成功");
            }
            return Map.of("success", false, "msg", "添加失败");

        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("success", false, "msg", "服务器异常：" + e.getMessage());
        }
    }

    private static String nowStr() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
    }
}
